# Handoff Summary (2025-10-12T19:51:53.051140Z)

## 実効設定
### カード順
- bitflyer, binance, bybit, okx

### 閾値（health.age_sec / latency_ms）
- age_sec warn=None crit=None
- latency_ms warn=None crit=None

### SLO (monitoring.slo)
- ticker: {'max_stale_s': 60}

## 実体ストレージ
- DATA: D:\BtcTS_V1\data
- LOGS: D:\BtcTS_V1\logs