# BtcTradeSystemV1 Handoff QuickStart

## 起動（ダッシュボード）
powershell:
  & "C:\Users\mint777\BtcTradeSystemV1\scripts\run.ps1"

## WhatIf（環境確認のみ）
  & "C:\Users\mint777\BtcTradeSystemV1\scripts\run.ps1" -WhatIf

## データ/ログ実体
  DATA = D:\BtcTS_V1\data
  LOGS = D:\BtcTS_V1\logs

## 参考
- config\health.yaml / monitoring.yaml : UIで保存した有効設定
- diagnostics\status_excerpt.json : 最新 status 抜粋
- diagnostics\audit.tail.jsonl : 監査末尾
